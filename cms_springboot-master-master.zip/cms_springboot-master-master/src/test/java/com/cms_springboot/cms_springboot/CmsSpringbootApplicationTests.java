package com.cms_springboot.cms_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
